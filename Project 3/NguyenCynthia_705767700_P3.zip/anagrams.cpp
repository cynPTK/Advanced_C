#include <iostream>
#include <fstream>
#include <istream>
#include <cstring>
#include <string>

using namespace std;

int lexiconBuilder(istream& dictfile, string dict[])
{
	string line;
    if (dictfile >> line)//retrieves every word in dictfile
    {
        dict[0] = line;
        return 1 + lexiconBuilder(dictfile, dict + 1);
    }
    return 0;
}

void Permutations(string prefix, string rest, const string& word, string results[], const string dict[], int& size, int& result_size);

//Loops for every letter in rest to be appended to prefix and removed from rest
 void LoopPerm(int i, int max, string& prefix, string& rest, const string& word, string results[], const string dict[], int& size, int& result_size) {
     if (i >= max)
        return;
     Permutations(prefix + rest[i], rest.substr(0, i) + rest.substr(i + 1), word, results, dict, size, result_size);
     LoopPerm(i + 1, max, prefix, rest, word, results, dict, size, result_size);
}

 //Loops to find if the word is in the dict
 void LoopDict(int i, int& max, string& prefix, string results[], const string dict[], int& result_size)
 {
     if (i >= max)
         return;
     if (dict[i] == prefix)//if word is in dict, add word into results[]
     {
         results[result_size] = prefix;
         result_size++;
         return;
     }
     LoopDict(i + 1, max, prefix, results, dict, result_size);
 }

 //Loops to find if the permutation is already in results
 bool LoopFindRep(int i, string& prefix, string results[], int& result_size)
 {
     if (i >= result_size)
         return true;
     if (results[i] == prefix)
         return false;
     return LoopFindRep(i + 1, prefix, results, result_size);
 }

 //finds all permutaions of a given word and puts into results[] if permutaion is in dict
 void Permutations(string prefix, string rest, const string& word, string results[], const string dict[], int& size, int& result_size) {
    if (rest.length() == 0) {
        if (prefix != word && LoopFindRep(0, prefix, results, result_size))//makes sure permuation is not already in results[] and is not the word
            LoopDict(0, size, prefix, results, dict, result_size);//cheks if it is in dict
    }
    else {
        LoopPerm(0, rest.length(), prefix, rest, word, results, dict, size, result_size);
    }
}

int theJumbler(string word, const string dict[], int size, string results[])
{
    if (word == "")//return 0 if word is empty string
        return 0;
    int result_size = 0;
    Permutations("", word, word, results, dict, size, result_size);//helper function to put all anagrams into results[] and return number of results
    return result_size;
}

//prints out all the anagrams in results[]
void divulgeSolutions(string results[], int numMatches)
{
    if (0 >= numMatches)
        return;
    cout << "Matching word " << results[0] << endl;
    divulgeSolutions(results + 1, numMatches - 1);
}

const int MAXRESULTS = 20;    // Max matches that can be found
const int MAXDICTWORDS = 30000; // Max words that can be read in
int main()
{
    string results[MAXRESULTS];
    string dict[MAXDICTWORDS];
    ifstream dictfile;         // file containing the list of words
    int nwords;                // number of words read from dictionary
    string word;
    dictfile.open("test.txt");
    if (!dictfile) {
        cout << "File not found!" << endl;
        return (1);
    }
    nwords = lexiconBuilder(dictfile, dict);
    cout << "nwords is: " << nwords << endl;
    cout << "Please enter a string for an anagram: ";
    cin >> word;
     int numMatches = theJumbler(word, dict, nwords, results);
     if (!numMatches) {
         cout << "No matches found" << endl;
     }
     else {
         divulgeSolutions(results, numMatches);
         cout << numMatches << endl;
     }
     return 0;
}